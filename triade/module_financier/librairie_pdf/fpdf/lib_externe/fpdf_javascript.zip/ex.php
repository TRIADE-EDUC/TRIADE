<?php
define('FPDF_FONTPATH','font/');
require('fpdf_js.php');

class PDF_AutoPrint extends PDF_Javascript
{
function AutoPrint($dialog=false)
{
	//Ajoute du JavaScript pour lancer la bo�te d'impression ou imprimer immediatement
	$param=($dialog ? 'true' : 'false');
	$script="print($param);";
	$this->IncludeJS($script);
}
}

$pdf=new PDF_AutoPrint();
$pdf->Open();
$pdf->AddPage();
$pdf->SetFont('Arial','',20);
$pdf->Text(80, 50, 'Imprimez-moi !');
//Ouvre la bo�te d'impression
$pdf->AutoPrint(true);
$pdf->Output();
?> 

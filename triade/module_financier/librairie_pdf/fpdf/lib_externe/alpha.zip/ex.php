<?php
require('alphapdf.php');

$pdf = new AlphaPDF();
$pdf->AddPage();
$pdf->SetLineWidth(1.5);

// trace un carr� rouge opaque
$pdf->SetFillColor(255,0,0);
$pdf->Rect(10,10,40,40,'DF');

// passe en mode semi-transparent
$pdf->SetAlpha(0.5);

// trace un carr� vert
$pdf->SetFillColor(0,255,0);
$pdf->Rect(20,20,40,40,'DF');

// affiche une image
$pdf->Image('lena.jpg',30,30,40);

// restaure une opacit� compl�te
$pdf->SetAlpha(1);

// imprime le nom
$pdf->SetFont('Arial', '', 12);
$pdf->Text(46,68,'Lena');

$pdf->Output();
?>
